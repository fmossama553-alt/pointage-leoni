package com.oussama.pointage

import android.app.Activity
import android.content.SharedPreferences
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

fun dailyEarnings(date: LocalDate, start: LocalTime, end: LocalTime, rate: Double): Double {
    val base = when (date.dayOfWeek) {
        DayOfWeek.SATURDAY -> 1.25
        DayOfWeek.SUNDAY -> 1.75
        else -> 1.0
    }
    var total = Duration.between(start, end).toMinutes()
    if (total < 0) total += 1440
    val startMin = start.hour * 60 + start.minute
    var sum = 0.0
    for (i in 0 until total.toInt()) {
        val minuteOfDay = (startMin + i) % 1440
        var mult = base
        if (i >= 480) mult = maxOf(mult, 1.25)
        if (minuteOfDay >= 17 * 60) mult = maxOf(mult, 1.25)
        sum += mult / 60.0
    }
    return sum * rate
}

class MainActivity : Activity(), NfcAdapter.ReaderCallback {

    private var nfc: NfcAdapter? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var card: TextView
    private lateinit var history: TextView
    private lateinit var etName: EditText
    private lateinit var etMat: EditText
    private lateinit var etRate: EditText
    private var lastScan = 0L
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pointage", MODE_PRIVATE)
        nfc = NfcAdapter.getDefaultAdapter(this)
        buildUi()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        val adapter = nfc
        if (adapter == null || !adapter.isEnabled) {
            toast("فعّل NFC من إعدادات التليفون")
            return
        }
        adapter.enableReaderMode(
            this, this,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            null
        )
    }

    override fun onPause() {
        super.onPause()
        nfc?.disableReaderMode(this)
    }

    override fun onTagDiscovered(tag: Tag) {
        val uid = tag.id.joinToString("") { "%02X".format(it) }
        runOnUiThread { handleScan(uid) }
    }

    private fun handleScan(uid: String) {
        val nowMs = System.currentTimeMillis()
        if (nowMs - lastScan < 60_000) return
        lastScan = nowMs

        val saved = prefs.getString("uid", "") ?: ""
        if (saved.isEmpty()) {
            prefs.edit().putString("uid", uid)
                .putString("start", LocalDate.now().toString()).apply()
            toast("تم ربط البادج: $uid")
            refresh()
            return
        }
        if (saved != uid) {
            toast("هذا البادج موش مسجل")
            return
        }
        val d = LocalDate.now().toString()
        val now = LocalTime.now().withNano(0).toString()
        when {
            prefs.getString("in_$d", null) == null -> {
                prefs.edit().putString("in_$d", now).apply()
                toast("تسجّل الدخول")
            }
            prefs.getString("out_$d", null) == null -> {
                prefs.edit().putString("out_$d", now).apply()
                toast("تسجّل الخروج")
            }
            else -> toast("الدخول والخروج متسجلين لهذا النهار")
        }
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun buildUi() {
        val sv = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        sv.addView(root)

        card = TextView(this).apply {
            textSize = 18f
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xFFE8F0FE.toInt())
        }
        root.addView(card)

        etName = EditText(this).apply {
            hint = "الاسم واللقب"
            setText(prefs.getString("name", ""))
        }
        etMat = EditText(this).apply {
            hint = "الماتريكول"
            setText(prefs.getString("mat", ""))
        }
        etRate = EditText(this).apply {
            hint = "سعر الساعة (دينار)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getString("rate", ""))
        }
        root.addView(etName)
        root.addView(etMat)
        root.addView(etRate)

        val save = Button(this).apply {
            text = "حفظ المعلومات"
            setOnClickListener {
                prefs.edit()
                    .putString("name", etName.text.toString().trim())
                    .putString("mat", etMat.text.toString().trim())
                    .putString("rate", etRate.text.toString().trim().replace(',', '.'))
                    .apply()
                toast("تم الحفظ")
                refresh()
            }
        }
        val relink = Button(this).apply {
            text = "إعادة ربط البادج"
            setOnClickListener {
                prefs.edit().remove("uid").apply()
                toast("قرّب البادج من ظهر التليفون")
                refresh()
            }
        }
        root.addView(save)
        root.addView(relink)

        history = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(history)
        setContentView(sv)
    }

    private fun getTime(key: String): LocalTime? =
        prefs.getString(key, null)?.let { LocalTime.parse(it) }

    private fun hoursBetween(a: LocalTime, b: LocalTime): Double {
        var m = Duration.between(a, b).toMinutes()
        if (m < 0) m += 1440
        return m / 60.0
    }

    private fun f(x: Double) = String.format(Locale.US, "%.2f", x)

    private fun refresh() {
        val name = prefs.getString("name", "") ?: ""
        val mat = prefs.getString("mat", "") ?: ""
        val uid = prefs.getString("uid", "") ?: ""
        val rate = prefs.getString("rate", "")?.toDoubleOrNull() ?: 0.0
        val today = LocalDate.now()

        val sb = StringBuilder()
        sb.append("الاسم: ").append(if (name.isEmpty()) "—" else name).append("\n")
        sb.append("الماتريكول: ").append(if (mat.isEmpty()) "—" else mat).append("\n")
        sb.append("البادج: ").append(if (uid.isEmpty()) "غير مربوط" else uid).append("\n")

        if (uid.isEmpty()) {
            sb.append("\nقرّب البادج من ظهر التليفون باش يتربط.")
        } else {
            val tin = getTime("in_$today")
            val tout = getTime("out_$today")
            sb.append("\nاليوم: ")
                .append(today.dayOfWeek.getDisplayName(TextStyle.FULL, Locale("ar"))).append("\n")
            sb.append("الحالة: ").append(if (tin != null) "حاضر" else "لم يسجّل بعد").append("\n")
            sb.append("الدخول: ").append(tin?.format(timeFmt) ?: "—").append("\n")
            sb.append("الخروج: ").append(tout?.format(timeFmt) ?: "—").append("\n")
            if (tin != null) {
                val h = hoursBetween(tin, tout ?: LocalTime.now())
                sb.append("الساعات: ").append(f(h)).append("\n")
                sb.append("ربح اليوم: ").append(f(dailyEarnings(today, tin, tout ?: LocalTime.now(), rate))).append(" د")
            }
        }
        card.text = sb.toString()

        val startStr = prefs.getString("start", null)
        val start = if (startStr != null) LocalDate.parse(startStr) else today
        val monthStart = today.withDayOfMonth(1)
        val from = if (start.isAfter(monthStart)) start else monthStart

        val hb = StringBuilder()
        var totalH = 0.0
        var totalE = 0.0
        var absences = 0
        var d = today
        while (!d.isBefore(from)) {
            val tin = getTime("in_$d")
            val tout = getTime("out_$d")
            val dayName = d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("ar"))
            hb.append("${d.dayOfMonth}/${d.monthValue} $dayName: ")
            if (tin != null) {
                val h = hoursBetween(tin, tout ?: if (d == today) LocalTime.now() else tin)
                val e = dailyEarnings(d, tin, tout ?: if (d == today) LocalTime.now() else tin, rate)
                totalH += h
                totalE += e
                hb.append("${tin.format(timeFmt)} → ${tout?.format(timeFmt) ?: "..."}  ")
                    .append("${f(h)} س  ${f(e)} د\n")
            } else {
                val weekend = d.dayOfWeek == DayOfWeek.SATURDAY || d.dayOfWeek == DayOfWeek.SUNDAY
                when {
                    d == today -> hb.append("—\n")
                    weekend -> hb.append("راحة\n")
                    else -> {
                        absences++
                        hb.append("غياب\n")
                    }
                }
            }
            d = d.minusDays(1)
        }
        val summary = "ملخص الشهر\nالساعات: ${f(totalH)}\nالأرباح: ${f(totalE)} د\nأيام الغياب: $absences\n\n"
        history.text = summary + hb.toString()
    }
}

# Pointage NFC
تطبيق أندرويد: حضور/غياب بالبادج NFC، بطاقة تعريف، وحساب الأجر.
بعد كل push: GitHub > Actions > Build APK > Artifacts > pointage-apk
